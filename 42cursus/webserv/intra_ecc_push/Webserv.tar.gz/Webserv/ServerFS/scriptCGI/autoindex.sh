#!/bin/bash

if [ $# -eq 0 ]; then
    echo "Usage: $0 <directory>"
    exit 1
fi

directory="$1"

echo "<html><head><title>AutoIndex</title></head><body><h1>Index of $directory</h1><ul>" 

for file in "$directory"/*; do
    filename=$(basename "$file")
    echo "<li><a href=\"$directory/$filename\">$filename</a></li>"
done

echo "</ul></body></html>"
exit 0
