/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Request.cpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mbardett <mbardett@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/19 22:12:01 by mbardett          #+#    #+#             */
/*   Updated: 2024/03/12 19:40:43 by mbardett         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Request.hpp"
#include <fstream>
#include <cstdio>
#include <sys/stat.h>
int findLocation(std::vector<Location> locations,std::string toMatch){
    toMatch += "/" + toMatch;
    int locLenght = 0;
    int bestLoc = -1;
    for(int i = 0; i < locations.size(); i++){
        std::string loc = locations[i].getLocation();
        if(loc.substr(0,loc.size()) == toMatch.substr(0,loc.size()) && loc.size() > locLenght){  
            locLenght = loc.size();
            bestLoc = i;
        }
    }
    return bestLoc;
}
std::string readFromFile(std::string path){
    std::ifstream file(path);

    std::string file_content;
    char ch;
    while (file.get(ch)) {
        file_content += ch;
    }
    file.close();
    return file_content;
}
std::string replaceDoubleSlashes(const std::string& str) {
    std::string result = str;
    std::string::size_type pos = 0;
    while ((pos = result.find("//", pos)) != std::string::npos) {
        result.replace(pos, 2, "/");
        pos += 1; // Avanza di uno per evitare di rimanere bloccati su sovrapposizioni
    }
    return result;
}
//da testare se funge
Request::Request(std::string request,  Server &src)
{
//uninitialized boolean value is unkwnown
    _isCgi = 0;
    _cgiType = "";
        if(request.size()==0)
        return;
    // Tokenize the request
    std::istringstream iss(request);
    std::string line;
    // Read the first line to get method, URI, and HTTP version
    std::getline(iss, line);
    std::istringstream firstLineStream(line);
    firstLineStream >> _reqType >> _reqTarget >> _version;//con get, post e delete abbiamo sempre un target path? 
    while (std::getline(iss, line)  && line.compare(std::string(""))) 
    {
        if (line.find("Connection:")!= std::string::npos)
        {
            setConnectionType(line.substr(line.find_first_of(" ") +1));
            std::cout << "\033[38;5;177m" << getConnectionType() <<"\033[0m" << std::endl;
        
        }
        _headers += line + "\r\n";
    }
    std::size_t idx = request.find(std::string("\r\n\r\n"));
    _body =request.substr(idx + 4);
    
    int i = findLocation(src.getLocation(),_reqTarget);
    std::string root = src.getRoot();
    std::string allowedMethods = "";
    if(i > -1){
        root  = src.getLocation()[i].getRoot();
        allowedMethods = src.getLocation()[i].getMethods() ;
        if(!src.getLocation()[i].getRedirectPage(301).empty()) {
            setResponseBody("<!DOCTYPE html>\n<a href=" + src.getLocation()[i].getRedirectPage(301)+ ">clicca qui</a>");
            setStatus("301");
        }
    }
    std::string  path = replaceDoubleSlashes(root + _reqTarget);
    std::cout << "path: " << path << std::endl;
    //test directory listing
    struct stat fileStat;
    if (!stat((path ).c_str(), &fileStat) && S_ISDIR(fileStat.st_mode))
    {
        std::cout << "\033[38;5;196m" << S_ISDIR(fileStat.st_mode) << "\033[0m" << std::endl;
        // if (S_ISDIR(fileStat.st_mode))
        // {
            startCGIscript("./ServerFS/scriptCGI/autoindex.sh", path);
            setStatus("200");
        // }
    }
    else if(_reqType.compare("GET") == 0 )
    {
        if(allowedMethods.find("GET") != std::string::npos)
        {

            if (isCgi().first == 1){
                std::cout << "\033[38;5;207mIS CGI "<< isCgi().first<< ",     " << isCgi().second << "\033[0m"<<  std::endl;
                parseURI();
                startCGIscript(  path,"");
                if(_statusCode == "500")
                    _fileContents += readFromFile(src.getErrorPage(500));
            }
            else
            {
                std::ifstream file(path);
                if (!file.is_open()) {
                    std::cerr << "Errore nell'apertura del file" << std::endl;
                    _statusCode = "404";
                    _fileContents += readFromFile(src.getErrorPage(404));

                }
                else {
                    std::string file_content;
                    char ch;
                    while (file.get(ch)) {
                        file_content += ch;
                    }
                    file.close();
                    _fileContents = file_content ;
                    _statusCode = "200";
                }
            }
        }else {
            _statusCode = "405";
            _fileContents += readFromFile(src.getErrorPage(405));
        }      
    }else if(!_reqType.compare("POST") && _body.size() <= src.getMaxBodySize()){
        std::cout << "qui"<< allowedMethods << std::endl;
        if(allowedMethods.find("POST") != std::string::npos){
            _fileContents = _body;
            std::cout << "." + path + ".txt" << std::endl;
            //std::ofstream file("./ServerFS/db/prova.txt", std::ios::out);
            std::ofstream file("." + path + ".txt", std::ios::out);
            if (file.is_open()) {
                _fileContents = _body;
                file << _body << std::endl;
                file.close();
                setStatus("201");
                std::cout << "Il file è stato scritto correttamente." << std::endl;
            } else {
                setStatus("500");
                _fileContents += readFromFile(src.getErrorPage(500));

                std::cerr << "Errore nell'apertura del file: " << strerror(errno) << std::endl;
                // Se non è possibile aprire il file, stampiamo un messaggio di errore
                std::cerr << "Impossibile aprire il file." << std::endl;
            }
        }else{
            _statusCode = "405";
            _fileContents += readFromFile(src.getErrorPage(405));
        }
    }else if(!_reqType.compare("DELETE")){
        if(allowedMethods.find("DELETE") != std::string::npos){
            std::cout <<  root +path + ".txt"<< std::endl;
            if (remove(("." + path + ".txt").c_str()) != 0) {
                // Se remove() restituisce un valore diverso da zero, c'è stato un errore durante l'eliminazione del file
                std::cout << "Errore durante l'eliminazione del file" << std::endl;
                setStatus("500");
                _fileContents += readFromFile(src.getErrorPage(500));

                }
        }else{
            _statusCode = "405";
            _fileContents += readFromFile(src.getErrorPage(405));
        }
    }else {
        _statusCode = "501";
        _fileContents += readFromFile(src.getErrorPage(501));
    }
    std::cout << "\033[38;5;51mMY REQUEST START-LINE "<< _reqType << "  " << _reqTarget << "  " << _version << "\033[0m"<< std::endl;
}

Request::~Request() {}

//bisogna aggiungere check per root e/o locations all'interno dell if-statement
//devi in questo momento, _cgiType = extension comprendono TUTTO quello che 
//cé'a partire dal punto del target fino alla fine dell'header, devi mettere un vincolo(" ")
std::pair<int, std::string> Request::isCgi()
{
    std::string targetPath = _reqTarget;
    std::string     extension;
    size_t          index;
    std::cout << targetPath << "  ++  " <<  targetPath.size() << std::endl;
    if ( targetPath.substr(targetPath.find_last_of(".") + 1, targetPath.find_first_of(" ")) == "sh" && targetPath.size() > 1)
    {
        _isCgi = 1;
        // extension = targetPath.substr(targetPath.find_last_of(".") + 1);
        extension = targetPath.substr(targetPath.find_last_of(".") + 1, targetPath.find_first_of(" "));

		_cgiType =  extension;
    }
    extension = targetPath.substr(targetPath.find_last_of(".") + 1, targetPath.find_first_of(" "));
    std::cout << "\033[38;5;106mTarget Extension is : " << extension << " end of extension\033[0m"<< std::endl;
    return (std::pair< int, std::string> (_isCgi, _cgiType));
}
std::string Request::getStatus(){return _statusCode;}
std::string Request::getPath() {return this->_path;}

void Request::setPath(std::string newPath) {this->_path = newPath;}

std::string Request::getResponseBody() {return this->_fileContents;}

void Request::setResponseBody(std::string str) {this->_fileContents = str;}
// 
void Request::setQueryParams(std::pair<std::string, std::string> pair)
{
    // std::vector<std::pair<std::string, std::string> >::iterator it = this->_queryParams.begin();
    // if (it == this->_queryParams.end())
    _queryParams.push_back(std::pair<std::string, std::string> (pair));    
    std::cout << " \033[38;5;67mADDED\033[0m "<< pair.first << "\033[38;5;67mAND \033[0m" << pair.second << "\033[38;5;67m TO _queryParams \033[0m" << std::endl;
}

int Request::parseURI()
{
    size_t pos = _reqTarget.find('?');
    if (pos != std::string::npos) 
    {
        _path = _reqTarget.substr(0, pos);
        std::string queryString = _reqTarget.substr(pos + 1);
        std::istringstream iss(queryString);
        std::string token;
        while (std::getline(iss, token, '&')) 
        {
            size_t eqPos = token.find('=');
            if (eqPos != std::string::npos) 
            {
                std::string key = token.substr(0, eqPos);
                std::string value = token.substr(eqPos + 1);
                std::pair<std::string, std::string> mypair = std::make_pair(key, value);
                setQueryParams(mypair);
            } else {
                continue;
            }
        }
        return 1; // Parameters found
    } else {
        // No query string found, the entire URI is the path
        setPath(_reqTarget);
        return 0; // No parameters found
    }
 }


 //adding stuff for CGI

 std::string Request::readFromPipe(int fileDescriptor) {
    std::string output;
    std::string buffer;
    char        buf[1024];
    int            bytesRead;

    while((bytesRead = read(fileDescriptor, buf, sizeof(buf) - 1)) > 0) {
        buf[bytesRead] = 0;
        output += buf;
    }

    return output;
}

//potremmo dover cambiare il secondo argomento con un std::set o std::pair, nella classe Request 
// ho salvato la query params come vector di coppie di stringhe(ovvero std::vector<std::pair<std::string, std::string> >)
// LE ULTIME DUE "> >" di chiusura del vector DEVONO ESSERE SEPARATE DA UNO SPAZIO
    void Request::startCGIscript(const std::string& scriptPath, const std::string& requestData) {
    extern char **environ;
    int pipe_fd[2];
    char* argv[] = {const_cast<char*>("/bin/bash"),const_cast<char*>(scriptPath.c_str()),const_cast<char*>(requestData.c_str()), nullptr};

    if (pipe(pipe_fd) == -1) {
        perror("Pipe error");   //TODO Prints a human-readable error message corresponding to the current value of errno to the standard error stream (stderr).
        return ;
    }

    pid_t pid = fork();
    if (pid == -1) {
        perror("Fork error");   //TODO Prints a human-readable error message corresponding to the current value of errno to the standard error stream (stderr).
        close(pipe_fd[0]);
        close(pipe_fd[1]);
        return ;
    }
    if (pid == 0) {
        dup2(pipe_fd[0], STDIN_FILENO);
        dup2(pipe_fd[1], STDOUT_FILENO);
    
        close(pipe_fd[0]);
        close(pipe_fd[1]);

        execve("/bin/bash", argv, environ);

        perror("execve error");     //TODO Prints a human-readable error message corresponding to the current value of errno to the standard error stream (stderr).
        exit(1);
    } else {

        //Scrivi i dati della richiesta nel pipe se necessario
        if (!requestData.empty()) {
            write(pipe_fd[1], requestData.c_str(), requestData.size());     //TODO To check the returned value
        }
        close(pipe_fd[1]);
        //variabile privata        
        _fileContents = readFromPipe(pipe_fd[0]);
        close(pipe_fd[0]);
        waitpid(pid, NULL, 0);
    }
        if(_fileContents.empty())
            _statusCode = "500";
        else
            _statusCode = "200";
}


void Request::setStatus( std::string code) {    this->_statusCode = code;}

void    Request::setConnectionType(std::string type) {this->_connectionType =  type;}

std::string Request::getConnectionType() {return this->_connectionType;}