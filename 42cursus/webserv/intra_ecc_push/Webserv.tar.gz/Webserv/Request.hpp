/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Request.hpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mbardett <mbardett@student.42roma.it>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/10 20:10:21 by mbardett          #+#    #+#             */
/*   Updated: 2024/02/25 15:30:02 by mbardett         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once

#include <sys/select.h> // select()
#include <sys/socket.h> //socket(), bind(), listen(), connect(), getsockname(), accept(), send(), struct sockaddr_in
#include <netdb.h> //getprotobyname()
#include <sys/types.h>
#include <arpa/inet.h> //ntohl() etc
#include <dirent.h> // readdir(), opendir(), closedir()
#include <unistd.h> //execve(), dup(), dup2(),
#include <signal.h>// 
#include <cstdlib>
#include <fcntl.h>
#include <iostream>
#include <fstream>
#include <map>
#include <set>
#include <sys/wait.h>
#include <vector>
#include <string>
#include <utility>

#include "Parser.hpp"

enum reqType{
	GET,
	POST,
	DELETE,
	UNKNOWN//else, per quelle che non dobbiamo gestire
};

class Server;

class Request
{
	private:
			Request();
			// Request(const Request &src);
			// Request &operator=(const Request &src);
		
			std::string		_requestCopy;
			std::string		_reqType;//GET, POST, DELETE o altro
			std::string		_reqTarget;//resource path
			std::string  	_version;// HTTP/1.1
			std::string		_headers;
			std::string		_body;
			//response/cgi
			std::string		_cgiType;
			int				_isCgi;

			std::string 	_path;//dovrebbe essere l'URI senza i parametri
			// std::set<std::string, std::string> _queryParams;//ho problemi ad inizializzarlo, provo con std::vector<std::pair<std::string, std::string>>
			std::vector<std::pair<std::string, std::string> >	_queryParams;
			std::string 			_statusCode;
			//
			std::string		_fileContents;
			std::string		_connectionType;
			

	public:
			Request(std::string request,  Server &src);
			// Request(const Request &src);
			// Request &operator=(const Request &src);
			~Request();
			std::string getStatus();
			std::pair<int, std::string> isCgi();
			std::string getPath();
			void setPath(std::string);
			std::string getResponseBody();
			void setResponseBody(std::string str);
			int	parseURI();
			//nella response
			void	setConnectionType(std::string);
			std::string getConnectionType();
			void setQueryParams(std::pair<std::string, std::string> pair);
			std::string readFromPipe(int fileDescriptor);
			void startCGIscript(const std::string& scriptPath, const std::string& requestData);
			void setStatus(std::string code);
};

