/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minirt.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/28 21:08:51 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/29 01:34:39 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINIRT_H
# define MINIRT_H

# include <math.h>
# include <fcntl.h>
# include <stdio.h>
# include <errno.h>
# include <unistd.h>
# include <stdlib.h>
# include <string.h>
# include <sys/stat.h>
# include <sys/types.h>
# include "minilibx-linux/mlx.h"
# include "libft/libft.h"
# include "structs.h"
# include "src/math/_math_.h"

# define WNDW_WIDTH 800
# define WNDW_HEIGTH 800

# define ESC 65307
# define C 99
# define L 108
# define Q 113
# define W 119
# define E 101
# define R 114
# define A 97
# define D 100
# define RX_ARROW 65363
# define LX_ARROW 65361
# define UP_ARROW 65362
# define DW_ARROW 65364
# define CTRL_RX  65508
# define ZERO_RX  65438
# define N_7 55
# define N_8 56
# define N_9 57
# define N_0 48

# define L_CLICK 1
# define R_CLICK 3
# define UP_WHEEL 4
# define DOWN_WHEEL 5

# define PI 3.14159265358979323846
# define EPS 0.000001
# define SPECULAR 50
# define FLT_MAX 1E+37

enum e_bool
{
	false,
	true,
};

enum e_io
{
	in,
	out,
	err,
};

enum e_objs {
	none,
	plane,
	sphere,
	cylinder,
	camera,
	light,
	basic_plane,
};

int				keyboard_manage(int key, t_scene *e);
t_color			rgb_to_int(int r, int g, int b);
t_ambient		*init_ambient_light(t_scene *s);
int				read_file(char *c, t_scene *s);
void			init_objects(t_scene *scene);
int				err_set(t_scene *s, char *c);
void			free_print_error(t_scene *s);
void			exit_minirt(t_scene *scene);
t_collision		*init_collision(t_scene *s);

int				window_cross(t_scene *e);
void			keyboard_aux(int key, t_scene *s);
int				mouse_manage(int key, int x, int y, t_scene *e);
void			key_a(t_scene *s);
void			key_a_aux(t_scene *s, t_vec3 k);
void			key_esc(t_scene *s);
void			key_d(t_scene *s);
void			key_d_aux(t_scene *s, t_vec3 k);
void			key_rx(t_scene *s);
void			key_lx(t_scene *s);
void			key_up(t_scene *s);
void			key_down(t_scene *s);
void			key_ctrl(t_scene *s);
void			key_zero_numpad(t_scene *s);
void			key_e(t_scene *s);
void			key_w(t_scene *s);
void			key_l(t_scene *s);
void			key_c(t_scene *s);
void			key_q(t_scene *s);
int				resize_selection(int key, t_scene *s);

int				render_loop(t_scene *scene);
void			free_scene(t_scene *scene);
t_color			vec_rgb_to_int(t_vec3 rgb);
t_cyl			*init_cylinder(t_scene *s);
float			ft_atofrt(const char *str);
char			**ft_strtok(char *buffer);
int				init_objs(t_scene *scene);
t_sphere		*init_sphere(t_scene *s);
int				window_cross(t_scene *e);
t_plane			*init_plane(t_scene *s);
t_light			*init_light(t_scene *s);
void			init_scene(t_scene *s);
t_cam			*init_cam(t_scene *s);
int				ft_tknnbr(char *str);
int				ft_isspace(char c);

#endif