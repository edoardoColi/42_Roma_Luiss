/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   scene_init1.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/18 22:46:17 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/28 21:40:17 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../minirt.h"

t_cyl	*init_cylinder(t_scene *s)
{
	t_cyl	*cyl;

	cyl = (t_cyl *) malloc(sizeof(t_cyl));
	if (!cyl)
		exit_minirt(s);
	cyl->next = NULL;
	cyl->type = NULL;
	cyl->versor = v_init(0, 0, 0);
	cyl->rgb = v_init(0, 0, 0);
	cyl->pos = v_init(0, 0, 0);
	cyl->heigth = 0;
	cyl->diam = 0;
	cyl->x = 0;
	cyl->y = 0;
	cyl->z = 0;
	return (cyl);
}

t_plane	*init_plane(t_scene *s)
{
	t_plane	*plane;

	plane = (t_plane *) malloc(sizeof(t_plane));
	if (!plane)
		exit_minirt(s);
	plane->type = 0;
	plane->orig = v_init(0, 0, 0);
	plane->versor = v_init(0, 0, 0);
	plane->rgb = v_init(0, 0, 0);
	plane->next = NULL;
	return (plane);
}

t_sphere	*init_sphere(t_scene *s)
{
	t_sphere	*sphere;

	sphere = (t_sphere *) malloc(sizeof(t_sphere));
	if (!sphere)
		exit_minirt(s);
	sphere->orig = v_init(0, 0, 0);
	sphere->next = NULL;
	sphere->type = 0;
	sphere->diam = 0;
	return (sphere);
}

t_collision	*init_collision(t_scene *s)
{
	t_collision	*col;

	col = (t_collision *) malloc(sizeof(t_collision));
	if (!col)
		exit_minirt(s);
	col->type = none;
	col->dist = FLT_MAX;
	col->sol1 = FLT_MAX;
	col->sol2 = FLT_MAX;
	col->sol_min = 0;
	col->base_norm = v_init(0, 0, 0);
	col->pla = NULL;
	col->sph = NULL;
	col->cyl = NULL;
	return (col);
}

void	set_collision(t_collision *col, int type, void *ptr)
{
	col->type = type;
	col->dist = FLT_MAX;
	col->pla = NULL;
	col->sph = NULL;
	col->cyl = NULL;
	if (type == plane)
		col->pla = (t_plane *) ptr;
	else if (type == sphere)
		col->sph = (t_sphere *) ptr;
	else if (type == cylinder)
		col->cyl = (t_cyl *) ptr;
}
