/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   scene_init0.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/18 22:56:33 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/28 12:18:08 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../minirt.h"

t_ambient	*init_ambient_light(t_scene *scene)
{
	t_ambient	*amb;

	amb = (t_ambient *) malloc(sizeof(t_ambient));
	if (!amb)
		exit_minirt(scene);
	amb->rgb = v_init(0, 0, 0);
	amb->next = NULL;
	amb->ratio = 0;
	amb->amb_n = 0;
	return (amb);
}

t_light	*init_light(t_scene *scene)
{
	t_light		*light;

	light = (t_light *) malloc(sizeof(t_light));
	if (!light)
		exit_minirt(scene);
	light->pos = v_init(0, 0, 0);
	light->rgb = v_init(0, 0, 0);
	light->next = NULL;
	light->type = NULL;
	light->bright = 0;
	light->x = 0;
	light->y = 0;
	light->z = 0;
	return (light);
}

t_cam	*init_cam(t_scene *scene)
{
	t_cam	*cam;

	cam = (t_cam *) malloc(sizeof(t_cam));
	if (!cam)
		exit_minirt(scene);
	cam->type = 0;
	cam->versor = v_init(0, 0, 0);
	cam->pos = v_init(0, 0, 0);
	cam->x = v_init(0, 0, 0);
	cam->y = v_init(0, 0, 0);
	cam->z = v_init(0, 0, 0);
	cam->fov = 0;
	cam->next = NULL;
	return (cam);
}

void	init_objects(t_scene *scene)
{
	scene->amb = NULL;
	scene->cyls = NULL;
	scene->cams_selez = NULL;
	scene->cams = NULL;
	scene->lights = NULL;
	scene->planes = NULL;
	scene->spheres = NULL;
	scene->col = init_collision(scene);
	scene->sel = (t_selected *) malloc(sizeof(t_selected));
	scene->sel->obj = NULL;
	scene->sel->type = 0;
}

void	init_scene(t_scene *scene)
{
	int		win_width;
	int		win_heigth;
	t_img	*img;

	win_width = WNDW_WIDTH;
	win_heigth = WNDW_HEIGTH;
	scene->mlx = mlx_init();
	scene->mlx_img = NULL;
	scene->mlx_win = mlx_new_window(scene->mlx, win_width,
			win_heigth, "miniRT");
	img = (t_img *) malloc(sizeof(t_img));
	img->img = mlx_new_image(scene->mlx, win_width, win_heigth);
	img->data = mlx_get_data_addr(img->img, &img->pxlb,
			&img->lineb, &img->endian);
	scene->mlx_img = img;
	scene->width = 0;
	scene->heigth = 0;
	scene->error_msg = NULL;
	scene->end_light.color = 0;
	scene->end_light.bright = 0;
	init_objects(scene);
}
