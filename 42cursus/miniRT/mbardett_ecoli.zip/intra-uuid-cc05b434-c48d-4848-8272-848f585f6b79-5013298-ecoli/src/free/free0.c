/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   free0.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/18 23:16:46 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/28 12:25:36 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "free.h"

static void	free_cams(t_cam *cam)
{
	t_cam	*nxt;

	if (!cam)
		return ;
	while (cam->next)
	{
		nxt = cam->next;
		ft_free_ptr(cam);
		cam = nxt;
	}
	ft_free_ptr(cam);
}

static void	free_lights(t_light *light)
{
	t_light	*nxt;

	if (!light)
		return ;
	while (light->next)
	{
		nxt = light->next;
		ft_free_ptr(light->type);
		ft_free_ptr(light);
		light = nxt;
	}
	ft_free_ptr(light->type);
	ft_free_ptr(light);
}

static void	free_ambient_lights(t_ambient *amb)
{
	t_ambient	*nxt;

	if (!amb)
		return ;
	while (amb->next)
	{
		nxt = amb->next;
		ft_free_ptr(amb);
		amb = nxt;
	}
	ft_free_ptr(amb);
}

void	free_scene(t_scene *scene)
{
	printf("\nFreeing all stuff...\n");
	free_print_error(scene);
	free_ambient_lights(scene->amb);
	free_spheres(scene->spheres);
	free_planes(scene->planes);
	free_lights(scene->lights);
	free_collision(scene->col);
	ft_free_ptr(scene->sel);
	free_cams(scene->cams);
	free_cyls(scene->cyls);
	if (scene->mlx)
	{
		mlx_destroy_window(scene->mlx, scene->mlx_win);
		mlx_destroy_image(scene->mlx, scene->mlx_img->img);
		mlx_destroy_display(scene->mlx);
		ft_free_ptr(scene->mlx_img);
		ft_free_ptr(scene->mlx);
	}
	printf("free completed!\n\n");
}

void	exit_minirt(t_scene *scene)
{
	free_scene(scene);
	exit(1);
}
