/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   free1.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/18 23:16:46 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/28 12:25:54 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "free.h"

void	free_cyls(t_cyl *cyl)
{
	t_cyl	*nxt;

	if (!cyl)
		return ;
	while (cyl->next)
	{
		nxt = cyl->next;
		ft_free_ptr(cyl->type);
		ft_free_ptr(cyl);
		cyl = nxt;
	}
	ft_free_ptr(cyl->type);
	ft_free_ptr(cyl);
}

void	free_planes(t_plane *plane)
{
	t_plane	*nxt;

	if (!plane)
		return ;
	while (plane->next)
	{
		nxt = plane->next;
		ft_free_ptr(plane);
		plane = nxt;
	}
	ft_free_ptr(plane);
}

void	free_spheres(t_sphere *sphere)
{
	t_sphere	*nxt;

	if (!sphere)
		return ;
	while (sphere->next)
	{
		nxt = sphere->next;
		ft_free_ptr(sphere);
		sphere = nxt;
	}
	ft_free_ptr(sphere);
}

void	free_collision(t_collision *col)
{
	ft_free_ptr(col);
}
