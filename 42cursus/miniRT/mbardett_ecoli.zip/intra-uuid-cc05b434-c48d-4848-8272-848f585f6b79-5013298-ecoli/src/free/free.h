/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   free.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/18 23:20:03 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/28 12:26:00 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FREE_H
# define FREE_H

# include "../../minirt.h"

void	free_collision(t_collision *col);
void	free_spheres(t_sphere *sphere);
void	free_planes(t_plane *plane);
void	free_cyls(t_cyl *cyl);

#endif