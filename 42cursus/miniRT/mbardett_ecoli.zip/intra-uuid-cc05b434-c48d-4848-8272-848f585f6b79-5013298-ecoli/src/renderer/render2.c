/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   render2.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/29 01:11:08 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/29 01:32:25 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "render.h"

void	closest_intersection(t_scene *scene, t_ray ray, float t_min)
{
	t_collision	*col;

	col = scene->col;
	col->dist = FLT_MAX;
	col->sol1 = FLT_MAX;
	col->sol2 = FLT_MAX;
	col->type = none;
	collide_spheres(scene->spheres, col, ray, t_min);
	collide_cyls(scene->cyls, col, ray, t_min);
	collide_planes(scene->planes, col, ray, t_min);
}

t_vec3	find_dir(t_scene *scene, float x, float y)
{
	t_vec3	sum;
	t_vec3	vx;
	t_vec3	vy;
	float	vw;
	float	vh;

	vw = tanf(scene->cams_selez->fov / 2.0f * (PI / 180));
	vh = vw * WNDW_HEIGTH / WNDW_WIDTH;
	vx = vec_mult(scene->cams_selez->y, vh * x);
	vy = vec_mult(scene->cams_selez->x, vw * y);
	sum = v_sum(vx, vy);
	sum = v_sum(sum, scene->cams_selez->z);
	sum = vec_normal(sum);
	return (sum);
}

void	config_cam(t_cam *cam)
{
	t_vec3	c;

	if (cam->versor.y != 0 && cam->versor.z == 0)
		c = v_init(0.0f, 0.0f, 1.0f);
	else
		c = v_init(0.0, 1.0f, 0.0f);
	cam->versor = vec_normal(cam->versor);
	cam->z = cam->versor;
	c = vec_cross(cam->z, c);
	cam->y = vec_normal(c);
	cam->x = vec_cross(cam->z, cam->y);
	cam->x = vec_normal(cam->x);
}

void	config_ambient(t_scene *scene)
{
	scene->end_light.color = vec_rgb_to_int(scene->amb->rgb);
	scene->end_light.bright = scene->amb->ratio;
}
