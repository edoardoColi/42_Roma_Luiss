/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   draw.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/28 23:54:14 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/29 01:30:34 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "render.h"

t_ray	ray_init(float f)
{
	t_ray	ray;

	ray.origin = v_init(f, f, f);
	ray.dir = v_init(f, f, f);
	return (ray);
}

void	my_mlx_pixel_put(t_scene *scene, int x, int y, int color)
{
	t_img	*img;

	img = scene->mlx_img;
	*(t_color *)(img->data + (y * img->lineb + x * (img->pxlb / 8))) = color;
}
