/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   lights.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/29 01:11:08 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/29 01:30:57 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "render.h"

t_color	intensity_check(t_light *l, t_color *color,
	t_color real_color, int flag)
{
	t_color	tmp;

	if (!l->next && (real_color == 0xFFFFFFFF || flag))
	{
		tmp = *color;
		*color = 0;
		if (flag)
			return (tmp);
		else
			return (13);
	}
	else if (real_color == 0xFFFFFFFF)
		return (13);
	else if (flag)
		return (*color);
	return (0);
}

t_vec3	reflect_ray(t_vec3 normal, t_vec3 rl)
{
	t_vec3	ref;

	ref = vec_mult(normal, v_dotp(normal, rl) * 2);
	ref = v_sub(ref, rl);
	return (ref);
}

t_color	intensity(t_light *light, t_vec3 normal, t_ray ray, t_color color)
{
	static unsigned int	scolor;
	t_vec3				rl;
	float				n_dot_l;
	float				r_dot_v;

	if (intensity_check(light, &scolor, color, 0))
		return (0);
	rl = v_sub(light->pos, ray.origin);
	rl = vec_normal(rl);
	n_dot_l = v_dotp(normal, rl);
	if (n_dot_l > 0)
		scolor = color_addition(scolor,
				multiply_lights(color, vec_rgb_to_int(light->rgb),
					light->bright * n_dot_l));
	rl = reflect_ray(normal, rl);
	r_dot_v = v_dotp(rl, ray.dir);
	if (r_dot_v > 0)
		scolor = color_addition(scolor, multiply_lights(color,
					vec_rgb_to_int(light->rgb), light->bright
					* powf(r_dot_v / (vec_len(rl) * vec_len(ray.dir)),
						SPECULAR)));
	return (intensity_check(light, &scolor, color, 1));
}

int	in_shadow(t_scene *scene, t_vec3 origin, t_vec3 light_dir)
{
	t_vec3	shadow;
	t_ray	r_light;

	r_light.origin = origin;
	r_light.dir = light_dir;
	closest_intersection(scene, r_light, 0.00001f);
	shadow = vec_mult(light_dir, scene->col->dist);
	shadow = v_sum(origin, shadow);
	shadow = v_sub(shadow, origin);
	if (scene->col->dist < FLT_MAX && (vec_len(light_dir) > vec_len(shadow)))
		return (1);
	else
		return (0);
}

// printf("object color: %d\n", *c);
// if (color == 0)
// {
// 	t_vec3 coll = int_to_rgb_vec(*c);
// 	coll = v_sub(coll, vec_mult(scene->amb->rgb, scene->end_light.bright));
// 	if (coll.x < 0)
// 		coll.x = 0;
// 	if (coll.y < 0)
// 		coll.y = 0;
// 	if (coll.z < 0) 
// 		coll.z = 0;
// 	*c = vec_rgb_to_int(coll);
// }
// else
void	set_color_by_lights(t_scene *scene, t_ray ray,
	t_vec3 normal, t_color *c)
{
	t_vec3	light_dir;
	t_light	*light;
	t_color	color;

	color = 0;
	light = scene->lights;
	while (light)
	{
		light_dir = v_sub(light->pos, ray.origin);
		if (in_shadow(scene, ray.origin, light_dir))
			intensity(light, normal, ray, 0xFFFFFFFF);
		else
			color = intensity(light, normal, ray, vec_rgb_to_int(light->rgb));
		light = light->next;
	}
	*c = color_addition(color, multiply_lights(*c,
				scene->end_light.color, scene->end_light.bright));
}
