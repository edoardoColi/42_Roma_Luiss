/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   collision_plane.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/25 12:49:04 by ecoli             #+#    #+#             */
/*   Updated: 2023/07/29 00:16:34 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "render.h"
#include <math.h>

// static void	intersect_plane(t_plane *pla, t_ray ray, float *sol1)
// {
// 	t_vec3	vec;
// 	float	a;
// 	float	b;

// 	pla->versor = vec_normal(pla->versor);
// 	vec = v_sub(ray.origin, pla->orig);
// 	a = v_dotp(vec, pla->versor);
// 	b = v_dotp(ray.dir, pla->versor);
// 	if (!b || (a < 0 && b < 0) || (a > 0 && b > 0))
// 	{
// 		*sol1 = FLT_MAX;
// 		return ;
// 	}
// 	*sol1 = -a / b;
// 	if (*sol1 < EPS)
// 	{
// 		*sol1 = FLT_MAX;
// 		return ;
// 	}
// }

void	intersect_plane(t_plane *pla, t_collision *col, t_ray ray)
{
	t_vec3	p;
	t_calc	c;

	c.a = v_dotp(ray.dir, pla->versor);
	if (c.a > 1e-6f)
	{
		c.b = v_dotp(pla->orig, pla->versor) - v_dotp(ray.origin, pla->versor);
		c.b /= c.a;
		p.x = ray.origin.x + c.b * ray.dir.x;
		p.y = ray.origin.y + c.b * ray.dir.y;
		p.z = ray.origin.z + c.b * ray.dir.z;
		p = v_sub(p, ray.origin);
		col->sol1 = sqrtf(p.x * p.x + p.y * p.y + p.z * p.z);
	}
	else
		col->sol1 = FLT_MAX;
}

//, &col->sol1);
void	collide_planes(t_plane *p, t_collision *col, t_ray ray, float t_min)
{
	t_plane	*pla;

	pla = p;
	while (pla)
	{
		intersect_plane(pla, col, ray);
		if (col->sol1 >= t_min && col->sol1 < col->dist && col->sol1 > EPS)
		{
			col->dist = col->sol1;
			col->type = plane;
			col->pla = pla;
			col->sph = NULL;
		}
		pla = pla->next;
	}
}
