/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   collision_sphere.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/25 12:49:04 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/28 15:47:03 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "render.h"

void	intersect_sphere(t_sphere *sph, t_collision *col, t_ray ray)
{
	t_vec3	p;
	t_calc	c;

	p = v_sub(ray.origin, sph->orig);
	c.a = v_dotp(ray.dir, ray.dir);
	c.b = 2.0f * v_dotp(p, ray.dir);
	c.c = v_dotp(p, p) - ((sph->diam / 2) * (sph->diam / 2));
	c.disc = (c.b * c.b) - (4 * c.a * c.c);
	col->sol1 = FLT_MAX;
	col->sol2 = FLT_MAX;
	if (c.disc < EPS)
		return ;
	col->sol1 = (-c.b + sqrt(c.disc)) / (2 * c.a);
	col->sol2 = (-c.b - sqrt(c.disc)) / (2 * c.a);
}

void	collide_spheres(t_sphere *s, t_collision *col, t_ray ray, float t_min)
{
	t_sphere	*sph;

	sph = s;
	while (sph)
	{
		intersect_sphere(sph, col, ray);
		if (col->sol1 >= t_min && col->sol1 < col->dist && col->sol1 > EPS)
		{
			col->dist = col->sol1;
			col->type = sphere;
			col->sph = sph;
		}
		if (col->sol2 >= t_min && col->sol2 < col->dist && col->sol2 > EPS)
		{
			col->dist = col->sol2;
			col->type = sphere;
			col->sph = sph;
		}
		sph = sph->next;
	}
}
