/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   render.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/29 01:11:08 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/29 01:29:48 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef RENDER_H
# define RENDER_H

# include "../../minirt.h"

void	collide_spheres(t_sphere *s, t_collision *c, t_ray r, float t);
void	collide_planes(t_plane *p, t_collision *col, t_ray ray, float t_min);
void	collide_cyls(t_cyl *c, t_collision *col, t_ray ray, float t_min);
void	collide_circles(t_plane *p, t_collision *col, t_ray ray, float t_min);
void	closest_intersection(t_scene *scene, t_ray ray, float t_min);

void	set_color_by_lights(t_scene *scene, t_ray ray, t_vec3 n, t_color *c);
void	my_mlx_pixel_put(t_scene *scene, int x, int y, int color);

t_color	multiply_lights(t_color c1, t_color c2, float c);
t_color	multiplication_color_constant(t_color color, float c);
t_color	create_trgb(unsigned char r, unsigned char g, unsigned char b);
t_color	color_addition(t_color c1, t_color c2);
float	check_channel(float channel);

void	closest_intersection(t_scene *scene, t_ray ray, float t_min);
t_vec3	find_dir(t_scene *scene, float x, float y);
void	config_ambient(t_scene *scene);
void	config_cam(t_cam *cam);
t_ray	ray_init(float f);

void	collide_cyls_old(t_cyl *c, t_collision *col, t_ray ray, float t_min);
float	find_edges3(t_cyl *cyl, t_vec3 o, t_vec3 d, float *t2);

#endif
