/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   render.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/29 01:21:45 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/29 01:32:16 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "render.h"

t_vec3	cylinder_normal(t_collision *col, t_cyl *cyl, t_ray ray, t_vec3 point)
{
	t_vec3	a;
	t_vec3	b;
	t_vec3	res;
	float	m;

	a = vec_mult(cyl->versor, col->dist);
	b = v_sub(ray.origin, cyl->pos);
	m = v_dotp(ray.dir, a) + v_dotp(b, cyl->versor);
	a = v_sub(point, cyl->pos);
	b = vec_mult(cyl->versor, m);
	res = v_sub(a, b);
	return (vec_normal(res));
}

t_vec3	get_normal_surface(t_collision *col, t_ray r, t_vec3 point)
{
	t_vec3	normal;

	normal = v_init(0, 0, 0);
	if (col->type == sphere)
	{
		normal = v_sub(point, col->sph->orig);
		normal = vec_normal(normal);
	}
	else if (col->type == plane)
	{
		normal = col->pla->versor;
		if (v_dotp(r.dir, normal) > EPS)
			normal = vec_mult(normal, -1);
	}
	else if (col->type == cylinder)
		normal = cylinder_normal(col, col->cyl, r, point);
	else if (col->type == basic_plane)
	{
		normal = col->base_norm;
		if (v_dotp(r.dir, normal) > EPS)
			normal = vec_mult(normal, -1);
	}
	return (normal);
}

void	set_pixel_initial_colors(t_collision *col, t_color *color,
	t_color *reflect)
{
	if (col->type == sphere)
	{
		*color = vec_rgb_to_int(col->sph->rgb);
		*reflect = vec_rgb_to_int(col->sph->rgb);
	}
	if (col->type == plane)
	{
		*color = vec_rgb_to_int(col->pla->rgb);
		*reflect = vec_rgb_to_int(col->pla->rgb);
	}
	if (col->type == cylinder || col->type == basic_plane)
	{
		*color = vec_rgb_to_int(col->cyl->rgb);
		*reflect = vec_rgb_to_int(col->cyl->rgb);
	}
}

t_color	trace_ray(t_scene *scene, t_ray r, float t_min)
{
	t_ray	ray;
	t_color	col;
	t_color	rcol;
	t_vec3	normal;

	col = 0;
	rcol = 0;
	closest_intersection(scene, r, t_min);
	if (scene->col->type == none)
		return (rgb_to_int(0, 0, 0));
	ray.origin = vec_mult(r.dir, scene->col->dist);
	ray.origin = v_sum(r.origin, ray.origin);
	ray.dir = vec_mult(r.dir, -1.0);
	normal = get_normal_surface(scene->col, r, ray.origin);
	set_pixel_initial_colors(scene->col, &col, &rcol);
	set_color_by_lights(scene, ray, normal, &col);
	return (col);
}

int	render_loop(t_scene *scene)
{
	t_pnt2	p;
	t_ray	ray;
	t_color	color;

	p.x = 0;
	ray = ray_init(0.0f);
	config_cam(scene->cams_selez);
	config_ambient(scene);
	while (p.x < WNDW_WIDTH)
	{
		p.y = 0;
		while (p.y < WNDW_HEIGTH)
		{
			ray.dir = find_dir(scene, (float) p.x * 2 / WNDW_WIDTH - 1,
					(float) p.y * 2 / WNDW_HEIGTH - 1);
			ray.origin = scene->cams_selez->pos;
			color = trace_ray(scene, ray, 1.0f);
			my_mlx_pixel_put(scene, p.x, p.y, color);
			p.y++;
		}
		p.x++;
	}
	mlx_put_image_to_window(scene->mlx, scene->mlx_win,
		scene->mlx_img->img, 0, 0);
	return (0);
}
