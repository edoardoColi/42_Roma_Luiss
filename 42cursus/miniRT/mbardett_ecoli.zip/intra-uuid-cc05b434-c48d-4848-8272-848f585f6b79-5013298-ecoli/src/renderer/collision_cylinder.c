/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   collision_cylinder.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ecoli <ecoli@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/29 01:13:19 by ecoli             #+#    #+#             */
/*   Updated: 2023/07/29 01:29:19 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "render.h"

float	get_lines_dist(t_vec3 p1, t_vec3 v1, t_vec3 p2, t_vec3 v2)
{
	t_vec3	short_direction;
	t_vec3	origin_diff;

	short_direction = vec_cross(v1, v2);
	short_direction = vec_normal(short_direction);
	origin_diff = v_sub(p1, p2);
	if (fabs(short_direction.x) < EPS && fabs(short_direction.x) < EPS && \
		fabs(short_direction.x) < EPS)
		return (vec_len(vec_cross(origin_diff, v2)));
	return (fabs(v_dotp(short_direction, origin_diff)));
}

float	find_edges2(t_cyl *cyl, t_vec3 o, t_vec3 d, float *t2)
{
	t_vec3	p2;
	t_calc	c2;
	t_vec3	cb;
	float	inside;

	c2.a = v_dotp(d, cyl->versor);
	if (c2.a > 1e-6f)
	{
		cb = v_sum(cyl->pos, vec_mult(cyl->versor, (cyl->heigth / -2.0f)));
		c2.b = v_dotp(cb, cyl->versor) - v_dotp(o, cyl->versor);
		c2.b /= c2.a;
		p2.x = o.x + c2.b * d.x;
		p2.y = o.y + c2.b * d.y;
		p2.z = o.z + c2.b * d.z;
		c2.disc = sqrtf((p2.x - cb.x) * (p2.x - cb.x) + (p2.y - cb.y)
				* (p2.y - cb.y) + (p2.z - cb.z) * (p2.z - cb.z));
		if (c2.disc <= (cyl->diam / 2.0f))
		{
			p2 = v_sub(p2, o);
			inside = sqrtf(p2.x * p2.x + p2.y * p2.y + p2.z * p2.z);
			if (inside < *t2)
				*t2 = inside;
		}
	}
	return (find_edges3(cyl, o, d, t2));
}

float	find_edges(t_cyl *cyl, t_vec3 o, t_vec3 d, float *t)
{
	float	max;
	t_vec3	point;
	t_vec3	len;
	float	t2;

	if (t[0] > t[1])
		t2 = t[1];
	else
		t2 = t[0];
	max = sqrtf(pow(cyl->heigth / 2, 2) + pow(cyl->diam * 0.5f, 2));
	point = v_sum(o, vec_mult(d, t2));
	len = v_sub(point, cyl->pos);
	if (vec_len(len) > max)
	{
		if (t[0] < t[1])
			t2 = t[1];
		else
			t2 = t[0];
		point = v_sum(o, vec_mult(d, t2));
		len = v_sub(point, cyl->pos);
		if (vec_len(len) > max)
			t2 = FLT_MAX;
	}
	return (find_edges2(cyl, o, d, &t2));
}

float	intersect_cylinder(t_ray *ray, t_cyl *cyl)
{
	t_vec3	inter;
	float	ret;
	t_vec3	r;
	t_vec3	c_to_o;
	float	t_arr[2];

	r = vec_cross(ray->dir, cyl->versor);
	c_to_o = v_sub(ray->origin, cyl->pos);
	inter.x = v_dotp(r, r);
	inter.y = 2 * v_dotp(r, vec_cross(c_to_o, cyl->versor));
	inter.z = v_dotp(vec_cross(c_to_o, cyl->versor), \
		vec_cross(c_to_o, cyl->versor)) - pow(cyl->diam * 0.5f, 2);
	ret = (inter.y * inter.y - (4 * inter.x * inter.z));
	if (ret < 0)
		return (FLT_MAX);
	t_arr[0] = ((-inter.y - sqrtf(ret)) / (2 * inter.x));
	t_arr[1] = ((-inter.y + sqrtf(ret)) / (2 * inter.x));
	return (find_edges(cyl, ray->origin, ray->dir, t_arr));
}

void	collide_cyls(t_cyl *cyl, t_collision *col, t_ray ray, float t_min)
{
	float	dist;

	(void)t_min;
	while (cyl)
	{
		dist = get_lines_dist(cyl->pos, cyl->versor, ray.origin, ray.dir);
		col->sol1 = intersect_cylinder(&ray, cyl);
		if (col->sol1 < FLT_MAX && col->sol1 < col->dist
			&& col->sol1 > EPS)
		{
			col->dist = col->sol1;
			col->type = cylinder;
			col->cyl = cyl;
		}
		cyl = cyl->next;
	}
}
