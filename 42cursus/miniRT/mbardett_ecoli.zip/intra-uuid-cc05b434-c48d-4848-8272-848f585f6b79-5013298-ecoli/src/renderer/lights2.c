/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   lights2.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/28 23:54:14 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/29 01:30:45 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "render.h"

float	check_channel(float channel)
{
	if (channel < 0.0f)
		return (0.0f);
	else if (channel > 255.0f)
		return (255.0f);
	return (channel);
}

t_color	color_addition(t_color c1, t_color c2)
{
	t_color	color;

	color = 0;
	color |= (t_color) check_channel(((c1 & 0x00FF0000) >> 16) \
			+ ((c2 & 0x00FF0000) >> 16)) << 16;
	color |= (t_color) check_channel(((c1 & 0x0000FF00) >> 8) \
			+ ((c2 & 0x0000FF00) >> 8)) << 8;
	color |= (t_color) check_channel((c1 & 0x000000FF) + (c2 & 0x000000FF));
	return (color);
}

t_color	create_trgb(unsigned char r, unsigned char g, unsigned char b)
{
	unsigned char	t;

	t = 255;
	return (*(t_color *)(unsigned char [4]){b, g, r, t});
}

t_color	multiplication_color_constant(t_color color, float c)
{
	float	red;
	float	green;
	float	blue;

	red = (float)((color & 0x00FF0000) >> 16) *c;
	green = (float)((color & 0x0000FF00) >> 8) *c;
	blue = (float)(color & 0x000000FF) *c;
	red = check_channel(red);
	green = check_channel(green);
	blue = check_channel(blue);
	return (create_trgb(red, green, blue));
}

t_color	multiply_lights(t_color c1, t_color c2, float c)
{
	t_color	color;
	float	channel;

	color = 0;
	channel = (float)((c2 & 0x00FF0000) >> 16) / 255.0f;
	color |= (unsigned int)((float)((c1 & 0x00FF0000) >> 16) *channel) << 16;
	channel = (float)((c2 & 0x0000FF00) >> 8) / 255.0f;
	color |= (unsigned int)((float)((c1 & 0x0000FF00) >> 8) *channel) << 8;
	channel = (float)(c2 & 0x000000FF) / 255.0f;
	color |= (unsigned int)((float)(c1 & 0x000000FF) *channel);
	return (multiplication_color_constant(color, c));
}
