/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   collision_cylinder2.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ecoli <ecoli@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/29 01:13:19 by ecoli             #+#    #+#             */
/*   Updated: 2023/07/29 01:29:19 by ecoli            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "render.h"

float	find_edges3(t_cyl *cyl, t_vec3 o, t_vec3 d, float *t2)
{
	t_vec3	p3;
	t_calc	c3;
	t_vec3	ct;
	float	inside;

	c3.a = v_dotp(d, cyl->versor);
	if (c3.a > 1e-6f)
	{
		ct = v_sum(cyl->pos, vec_mult(cyl->versor, (cyl->heigth / 2.0f)));
		c3.b = v_dotp(ct, cyl->versor) - v_dotp(o, cyl->versor);
		c3.b /= c3.a;
		p3.x = o.x + c3.b * d.x;
		p3.y = o.y + c3.b * d.y;
		p3.z = o.z + c3.b * d.z;
		c3.disc = sqrtf((p3.x - ct.x) * (p3.x - ct.x) + (p3.y - ct.y)
				* (p3.y - ct.y) + (p3.z - ct.z) * (p3.z - ct.z));
		if (c3.disc <= (cyl->diam / 2.0f))
		{
			p3 = v_sub(p3, o);
			inside = sqrtf(p3.x * p3.x + p3.y * p3.y + p3.z * p3.z);
			if (inside < *t2)
				*t2 = inside;
		}
	}
	return (*t2);
}
