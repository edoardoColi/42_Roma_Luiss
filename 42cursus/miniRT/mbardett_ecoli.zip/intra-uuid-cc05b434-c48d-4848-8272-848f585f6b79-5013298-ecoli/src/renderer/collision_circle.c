/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   collision_plane.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/25 12:49:04 by ecoli             #+#    #+#             */
/*   Updated: 2023/07/29 00:16:34 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "render.h"
#include <math.h>

void	intersect_circle(t_plane *pla, t_collision *col, t_ray ray)
{
	t_vec3	p;
	t_calc	c;
	float	r;

	c.a = v_dotp(ray.dir, pla->versor);
	if (c.a > 1e-6f)
	{
		c.b = v_dotp(pla->orig, pla->versor) - v_dotp(ray.origin, pla->versor);
		c.b /= c.a;
		p.x = ray.origin.x + c.b * ray.dir.x;
		p.y = ray.origin.y + c.b * ray.dir.y;
		p.z = ray.origin.z + c.b * ray.dir.z;
		r = sqrtf((p.x - pla->orig.x) * (p.x - pla->orig.x) + (p.y
					- pla->orig.y) * (p.y - pla->orig.y) + (p.z - pla->orig.z)
				* (p.z - pla->orig.z));
		if (r <= 2.0f)
		{
			p = v_sub(p, ray.origin);
			col->sol1 = sqrtf(p.x * p.x + p.y * p.y + p.z * p.z);
		}
		else
			col->sol1 = FLT_MAX;
	}
	else
		col->sol1 = FLT_MAX;
}

void	collide_circles(t_plane *p, t_collision *col, t_ray ray, float t_min)
{
	t_plane	*pla;

	pla = p;
	while (pla)
	{
		intersect_circle(pla, col, ray);
		if (col->sol1 >= t_min && col->sol1 < col->dist && col->sol1 > EPS)
		{
			col->dist = col->sol1;
			col->type = plane;
			col->pla = pla;
			col->sph = NULL;
		}
		pla = pla->next;
	}
}
