/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   triggers3.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/29 01:11:08 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/29 01:32:45 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../minirt.h"

int	mouse_manage(int key, int x, int y, t_scene *s)
{
	(void)x;
	(void)y;
	if (key == L_CLICK)
	{
		printf("DEBUG - (pressed L_CLICK)\n");
		render_loop(s);
	}
	if (key == R_CLICK)
	{
		printf("DEBUG - (pressed R_CLICK)\n");
		render_loop(s);
	}
	if (key == UP_WHEEL)
	{
		printf("DEBUG - (pressed UP_WHEEL)\n");
		render_loop(s);
	}
	if (key == DOWN_WHEEL)
	{
		printf("DEBUG - (pressed DOWN_WHEEL)\n");
		render_loop(s);
	}
	return (0);
}

void	key_esc(t_scene *s)
{
	free_scene(s);
	printf("This seems to be the ESC\n");
	exit(0);
}

int	window_cross(t_scene *s)
{
	free_scene(s);
	printf("Just put a CROSS on it\n");
	exit(0);
	return (0);
}

void	key_d_aux(t_scene *s, t_vec3 k)
{
	t_cam	*cam;

	k = v_init(0, 1, 0);
	cam = ((t_cam *)s->sel->obj);
	cam->versor = v_sum(v_sum(vec_mult(cam->versor, cosf(-0.2f)),
				vec_mult(vec_cross(k, cam->versor), sinf(-0.2f))),
			vec_mult(k, (v_dotp(k, cam->versor) * (1 - cosf(0.2f)))));
}

void	key_a_aux(t_scene *s, t_vec3 k)
{
	t_cam	*cam;

	k = v_init(0, 1, 0);
	cam = ((t_cam *)s->sel->obj);
	cam->versor = v_sum(v_sum(vec_mult(cam->versor, cosf(+0.2f)),
				vec_mult(vec_cross(k, cam->versor), sinf(+0.2f))),
			vec_mult(k, (v_dotp(k, cam->versor) * (1 - cosf(0.2f)))));
}
