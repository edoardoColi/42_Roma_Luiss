/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   triggers.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/02 04:14:26 by eddy              #+#    #+#             */
/*   Updated: 2023/07/29 00:53:36 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../minirt.h"

void	key_a(t_scene *s)
{
	t_vec3	k;
	t_plane	*p;
	t_cyl	*cy;

	if (s->sel->type == plane)
	{
		k = s->cams->versor;
		p = ((t_plane *)s->sel->obj);
		p->versor = v_sum(v_sum(vec_mult(p->versor, cosf(+0.2f)),
					vec_mult(vec_cross(k, p->versor), sinf(+0.2f))),
				vec_mult(k, (v_dotp(k, p->versor) * (1 - cosf(0.2f)))));
	}
	if (s->sel->type == cylinder)
	{
		k = s->cams->versor;
		cy = ((t_cyl *)s->sel->obj);
		cy->versor = v_sum(v_sum(vec_mult(cy->versor, cosf(+0.2f)),
					vec_mult(vec_cross(k, cy->versor), sinf(+0.2f))),
				vec_mult(k, (v_dotp(k, cy->versor)
						* (1 - cosf(0.2f)))));
	}
	if (s->sel->type == camera)
		key_a_aux(s, k);
	render_loop(s);
}

void	key_d(t_scene *s)
{
	t_vec3	k;
	t_plane	*p;
	t_cyl	*cy;

	if (s->sel->type == plane)
	{
		k = s->cams->versor;
		p = ((t_plane *)s->sel->obj);
		p->versor = v_sum(v_sum(vec_mult(p->versor, cosf(-0.2f)),
					vec_mult(vec_cross(k, p->versor), sinf(-0.2f))),
				vec_mult(k, (v_dotp(k, p->versor) * (1 - cosf(0.2f)))));
	}
	if (s->sel->type == cylinder)
	{
		k = s->cams->versor;
		cy = ((t_cyl *)s->sel->obj);
		cy->versor = v_sum(v_sum(vec_mult(cy->versor, cosf(-0.2f)),
					vec_mult(vec_cross(k, cy->versor), sinf(-0.2f))),
				vec_mult(k, (v_dotp(k, cy->versor) * (1 - cosf(0.2f)))));
	}
	if (s->sel->type == camera)
		key_d_aux(s, k);
	render_loop(s);
}

int	resize_selection(int key, t_scene *s)
{
	if (s->sel->type == sphere)
	{
		if (key == N_7)
			((t_sphere *)s->sel->obj)->diam -= 2.0f;
		if (key == N_8)
			((t_sphere *)s->sel->obj)->diam += 2.0f;
	}
	if (s->sel->type == cylinder)
	{
		if (key == N_7 && ((t_cyl *)s->sel->obj)->diam - 2.f > 3)
			((t_cyl *)s->sel->obj)->diam -= 2.0f;
		if (key == N_8)
			((t_cyl *)s->sel->obj)->diam -= 2.0f;
		if (key == N_9 && ((t_cyl *)s->sel->obj)->heigth - 2.f > 3)
			((t_cyl *)s->sel->obj)->heigth -= 2.0f;
		if (key == N_0)
			((t_cyl *)s->sel->obj)->heigth += 2.0f;
	}
	render_loop(s);
	return (0);
}

void	keyboard_aux(int key, t_scene *s)
{
	if (key == C)
		key_c(s);
	else if (key == L)
		key_l(s);
	else if (key == W)
		key_w(s);
	else if (key == E)
		key_e(s);
	else if (key == Q)
		key_q(s);
	else
		resize_selection(key, s);
}

int	keyboard_manage(int key, t_scene *s)
{
	if (key == ESC)
		key_esc(s);
	if (key == A && s->sel->type != sphere && s->sel->type != light)
		key_a(s);
	if (key == D && s->sel->type != sphere && s->sel->type != light)
		key_d(s);
	if (key == RX_ARROW)
		key_rx(s);
	if (key == LX_ARROW)
		key_lx(s);
	if (key == UP_ARROW)
		key_up(s);
	if (key == DW_ARROW)
		key_down(s);
	if (key == CTRL_RX)
		key_ctrl(s);
	if (key == ZERO_RX)
		key_zero_numpad(s);
	else
		keyboard_aux(key, s);
	return (0);
}
