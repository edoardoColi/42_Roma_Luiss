/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   triggers4.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/29 01:11:08 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/29 01:32:48 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../minirt.h"

void	key_q(t_scene *s)
{
	t_plane	*ob;

	ob = ((t_plane *)s->sel->obj);
	if (s->planes == NULL)
		return ;
	printf("new Plane selected - (pressed Q)\n");
	if (s->sel->type == plane && ob->next != NULL)
	{
		s->sel->obj = ob->next;
		ob = ((t_plane *)s->sel->obj);
		printf("Plane (%.2f,%.2f,%.2f)\n", ob->orig.x, ob->orig.y, ob->orig.z);
	}
	else
	{
		s->sel->type = plane;
		s->sel->obj = s->planes;
		ob = ((t_plane *)s->sel->obj);
		printf("Plane (%.2f,%.2f,%.2f)\n", ob->orig.x, ob->orig.y, ob->orig.z);
	}
	render_loop(s);
}
