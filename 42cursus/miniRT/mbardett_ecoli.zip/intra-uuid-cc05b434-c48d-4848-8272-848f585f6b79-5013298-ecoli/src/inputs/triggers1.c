/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   triggers1.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/29 01:11:08 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/29 01:32:39 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../minirt.h"

void	key_zero_numpad(t_scene *s)
{
	if (s->sel->type == plane)
		((t_plane *)s->sel->obj)->orig.z -= 1.0f;
	if (s->sel->type == sphere)
		((t_sphere *)s->sel->obj)->orig.z -= 1.0f;
	if (s->sel->type == cylinder)
		((t_cyl *)s->sel->obj)->pos.z -= 1.0f;
	if (s->sel->type == camera)
		((t_cam *)s->sel->obj)->pos.z -= 1.0f;
	if (s->sel->type == light)
		((t_light *)s->sel->obj)->pos.z -= 1.0f;
	render_loop(s);
}

void	key_c(t_scene *s)
{
	t_cam	*ob;

	ob = ((t_cam *)s->sel->obj);
	if (s->cams == NULL)
		return ;
	printf("new Camera selected - (pressed C)\n");
	if (s->sel->type == camera && ob->next != NULL)
	{
		s->sel->obj = ob->next;
		ob = ((t_cam *)s->sel->obj);
		s->cams_selez = ob;
		printf("Camera (%.2f,%.2f,%.2f)\n", ob->pos.x, ob->pos.y, ob->pos.z);
	}
	else
	{
		s->sel->type = camera;
		s->sel->obj = s->cams;
		ob = ((t_cam *)s->sel->obj);
		s->cams_selez = ob;
		printf("Camera (%.2f,%.2f,%.2f)\n", ob->pos.x, ob->pos.y, ob->pos.z);
	}
	render_loop(s);
}

void	key_l(t_scene *s)
{
	t_light	*ob;

	ob = ((t_light *)s->sel->obj);
	if (s->lights == NULL)
		return ;
	printf("new light selected - (pressed L)\n");
	if (s->sel->type == light && ob->next != NULL)
	{
		s->sel->obj = ob->next;
		ob = ((t_light *)s->sel->obj);
		printf("light (%.2f,%.2f,%.2f)\n", ob->pos.x, ob->pos.y, ob->pos.z);
	}
	else
	{
		s->sel->type = light;
		s->sel->obj = s->lights;
		ob = ((t_light *)s->sel->obj);
		printf("light (%.2f,%.2f,%.2f)\n", ob->pos.x, ob->pos.y, ob->pos.z);
	}
	render_loop(s);
}

void	key_w(t_scene *s)
{
	t_sphere	*ob;

	ob = ((t_sphere *)s->sel->obj);
	if (s->spheres == NULL)
		return ;
	printf("new sphere selected - (pressed W)\n");
	if (s->sel->type == sphere && ob->next != NULL)
	{
		s->sel->obj = ob->next;
		ob = ((t_sphere *)s->sel->obj);
		printf("sphere color %.2f,%.2f,%.2f\n", ob->rgb.x, ob->rgb.y, ob->rgb.z);
	}
	else
	{
		s->sel->type = sphere;
		s->sel->obj = s->spheres;
		ob = ((t_sphere *)s->sel->obj);
		printf("sphere color %.2f,%.2f,%.2f\n", ob->rgb.x, ob->rgb.y, ob->rgb.z);
	}
	render_loop(s);
}

void	key_e(t_scene *s)
{
	t_cyl	*ob;

	if (s->cyls == NULL)
		return ;
	ob = ((t_cyl *)s->sel->obj);
	printf("new cylinder selected - (pressed E)\n");
	if (s->sel->type == cylinder && ob->next != NULL)
	{
		s->sel->obj = ob->next;
		ob = ((t_cyl *)s->sel->obj);
		printf("cylinder color %.2f,%.2f,%.2f\n",
			ob->rgb.x, ob->rgb.y, ob->rgb.z);
	}
	else
	{
		s->sel->type = cylinder;
		s->sel->obj = s->cyls;
		ob = ((t_cyl *)s->sel->obj);
		printf("cylinder color %.2f,%.2f,%.2f\n",
			ob->rgb.x, ob->rgb.y, ob->rgb.z);
	}
	render_loop(s);
}
