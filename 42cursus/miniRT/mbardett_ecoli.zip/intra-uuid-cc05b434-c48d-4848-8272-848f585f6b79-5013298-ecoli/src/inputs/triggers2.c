/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   triggers2.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/29 01:11:08 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/29 01:32:42 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../minirt.h"

void	key_rx(t_scene *s)
{
	if (s->sel->type == plane)
		((t_plane *)s->sel->obj)->orig.x -= 1.0f;
	if (s->sel->type == sphere)
		((t_sphere *)s->sel->obj)->orig.x -= 1.0f;
	if (s->sel->type == cylinder)
		((t_cyl *)s->sel->obj)->pos.x -= 1.0f;
	if (s->sel->type == camera)
		((t_cam *)s->sel->obj)->pos.x -= 1.0f;
	if (s->sel->type == light)
		((t_light *)s->sel->obj)->pos.x -= 1.0f;
	render_loop(s);
}

void	key_lx(t_scene *s)
{
	if (s->sel->type == plane)
		((t_plane *)s->sel->obj)->orig.x += 1.0f;
	if (s->sel->type == sphere)
		((t_sphere *)s->sel->obj)->orig.x += 1.0f;
	if (s->sel->type == cylinder)
		((t_cyl *)s->sel->obj)->pos.x += 1.0f;
	if (s->sel->type == camera)
		((t_cam *)s->sel->obj)->pos.x += 1.0f;
	if (s->sel->type == light)
		((t_light *)s->sel->obj)->pos.x += 1.0f;
	render_loop(s);
}

void	key_up(t_scene *s)
{
	if (s->sel->type == plane)
		((t_plane *)s->sel->obj)->orig.y += 1.0f;
	if (s->sel->type == sphere)
		((t_sphere *)s->sel->obj)->orig.y += 1.0f;
	if (s->sel->type == cylinder)
		((t_cyl *)s->sel->obj)->pos.y += 1.0f;
	if (s->sel->type == camera)
		((t_cam *)s->sel->obj)->pos.y += 1.0f;
	if (s->sel->type == light)
		((t_light *)s->sel->obj)->pos.y += 1.0f;
	render_loop(s);
}

void	key_down(t_scene *s)
{
	if (s->sel->type == plane)
		((t_plane *)s->sel->obj)->orig.y -= 1.0f;
	if (s->sel->type == sphere)
		((t_sphere *)s->sel->obj)->orig.y -= 1.0f;
	if (s->sel->type == cylinder)
		((t_cyl *)s->sel->obj)->pos.y -= 1.0f;
	if (s->sel->type == camera)
		((t_cam *)s->sel->obj)->pos.y -= 1.0f;
	if (s->sel->type == light)
		((t_light *)s->sel->obj)->pos.y -= 1.0f;
	render_loop(s);
}

void	key_ctrl(t_scene *s)
{
	if (s->sel->type == plane)
		((t_plane *)s->sel->obj)->orig.z += 1.0f;
	if (s->sel->type == sphere)
		((t_sphere *)s->sel->obj)->orig.z += 1.0f;
	if (s->sel->type == cylinder)
		((t_cyl *)s->sel->obj)->pos.z += 1.0f;
	if (s->sel->type == camera)
		((t_cam *)s->sel->obj)->pos.z += 1.0f;
	if (s->sel->type == light)
		((t_light *)s->sel->obj)->pos.z += 1.0f;
	render_loop(s);
}
