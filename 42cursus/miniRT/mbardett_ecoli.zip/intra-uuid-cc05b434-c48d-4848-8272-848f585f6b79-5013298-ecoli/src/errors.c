/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   errors.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/19 19:47:47 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/19 21:50:10 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minirt.h"

int	err_set(t_scene *scene, char *msg)
{
	size_t	i;

	if (scene->error_msg)
		return (1);
	i = 0;
	scene->error_msg = ft_calloc(sizeof(char), ft_strlen(msg) + 1);
	while (msg[i])
	{
		scene->error_msg[i] = msg[i];
		i++;
	}
	return (1);
}

void	free_print_error(t_scene *scene)
{
	if (!scene->error_msg)
		return ;
	ft_putstr_fd("Error\n", 2);
	ft_putstr_fd(scene->error_msg, 2);
	ft_free_ptr(scene->error_msg);
}
