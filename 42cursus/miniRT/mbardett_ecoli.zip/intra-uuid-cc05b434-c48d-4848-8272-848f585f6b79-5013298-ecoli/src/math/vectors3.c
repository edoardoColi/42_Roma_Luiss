/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   vectors3.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/28 16:31:23 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/28 23:55:26 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "_math_.h"

t_vec3	*v_init_ptr(float x, float y, float z)
{
	t_vec3	*vec;

	vec = (t_vec3 *) malloc(sizeof(t_vec3));
	vec->x = x;
	vec->y = y;
	vec->z = z;
	return (vec);
}

t_vec3	vec_normal(t_vec3 vec)
{
	t_vec3	normal;
	float	len;

	len = 0;
	len = vec_len(vec);
	normal.x = vec.x / len;
	normal.y = vec.y / len;
	normal.z = vec.z / len;
	return (normal);
}

t_vec3	vec_cross(t_vec3 a, t_vec3 b)
{
	t_vec3	vec;

	vec.x = (a.y * b.z) - (a.z * b.y);
	vec.y = (a.z * b.x) - (a.x * b.z);
	vec.z = (a.x * b.y) - (a.y * b.x);
	return (vec);
}
