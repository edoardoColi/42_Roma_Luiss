/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   vectors1.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/28 16:31:23 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/28 23:55:12 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "_math_.h"

//v_sum
t_vec3	v_sum(t_vec3 vec1, t_vec3 vec2)
{
	t_vec3	v_sum;

	v_sum.x = vec1.x + vec2.x;
	v_sum.y = vec1.y + vec2.y;
	v_sum.z = vec1.z + vec2.z;
	return (v_sum);
}

//vec_sub
t_vec3	v_sub(t_vec3 vec1, t_vec3 vec2)
{
	t_vec3	v_sub;

	v_sub.x = vec1.x - vec2.x;
	v_sub.y = vec1.y - vec2.y;
	v_sub.z = vec1.z - vec2.z;
	return (v_sub);
}

//v_dotp prodotto scalare
float	v_dotp(t_vec3 vec1, t_vec3 vec2)
{
	return ((vec1.x * vec2.x) + (vec1.y * vec2.y) + (vec1.z * vec2.z));
}

//vector maginitude/mmodulus
float	v_mod(t_vec3 vec)
{
	float	mod;

	mod = sqrtf(v_dotp(vec, vec));
	return (mod);
}

float	a_theta(t_vec3 vec1, t_vec3 vec2)
{
	float	theta;

	theta = acosf(v_dotp(vec1, vec2) * 1 / (v_mod(vec1) * v_mod(vec2)));
	return (theta);
}
