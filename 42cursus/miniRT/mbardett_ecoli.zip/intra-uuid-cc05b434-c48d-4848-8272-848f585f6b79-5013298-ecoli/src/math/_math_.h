/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   _math_.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/28 20:34:10 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/28 23:55:03 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef _MATH__H
# define _MATH__H

# include "../../minirt.h"

float	a_theta(t_vec3 vec1, t_vec3 vec2);
float	v_dotp(t_vec3 vec1, t_vec3 vec2);
t_vec3	v_sub(t_vec3 vec1, t_vec3 vec2);
t_vec3	v_sum(t_vec3 vec1, t_vec3 vec2);
float	v_mod(t_vec3 vec);

t_vec3	*v_init_ptr(float x, float y, float z);
float	vec_distance(t_vec3 v1, t_vec3 v2);
t_vec3	v_init(float x, float y, float z);
t_vec3	vec_mult(t_vec3 vec, float m);
t_vec3	vec_cross(t_vec3 a, t_vec3 b);
t_vec3	vec_normal(t_vec3 vec);
t_vec3	vec_invert(t_vec3 vec);
float	vec_len(t_vec3 v1);

t_vec3	int_to_rgb_vec(t_color c);
float	set_float(char *buff, int i);

#endif