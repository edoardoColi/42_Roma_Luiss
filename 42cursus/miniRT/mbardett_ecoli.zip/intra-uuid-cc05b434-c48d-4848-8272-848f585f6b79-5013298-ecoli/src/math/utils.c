/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/28 16:31:23 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/28 23:57:27 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "_math_.h"

float	set_float(char *buff, int i)
{
	float	f;
	int		i_size;
	int		sign;

	(void)i;
	i_size = 0;
	sign = 0;
	f = 0.0;
	while (buff[i_size])
	{
		if (buff[i_size] == '-' || buff[i_size] == '+')
			sign++;
		i_size++;
	}
	if (sign > 1)
		return (-1); 
	f = ft_atofrt(buff);
	return (f);
}

float	dist(t_pnt3 a, t_pnt3 b)
{
	float	dist;

	dist = sqrtf((b.x - a.x) * (b.x - a.x) + (b.y - a.y) 
			* (b.y - a.y) + (b.z - a.z) * (b.z - a.z));
	return (dist);
}

//p_trans = traslazione di un punto
t_pnt3	*p_trans(t_pnt3 p, t_vec3 translate)
{
	t_pnt3	*new_pos;

	new_pos = NULL;
	new_pos->x = translate.x + p.x;
	new_pos->y = translate.y + p.y;
	new_pos->z = translate.z + p.z;
	return (new_pos);
}

t_vec3	int_to_rgb_vec(t_color c)
{
	unsigned int	r;
	unsigned int	g;
	unsigned int	b;

	r = (c & 0x00ff0000) >> 16;
	g = (c & 0x0000ff00) >> 8;
	b = (c & 0x000000ff);
	return (v_init(r, g, b));
}
