/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   vectors2.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/28 16:31:23 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/28 23:55:20 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "_math_.h"

t_vec3	v_init(float x, float y, float z)
{
	t_vec3	vec;

	vec.x = x;
	vec.y = y;
	vec.z = z;
	return (vec);
}

t_vec3	vec_mult(t_vec3 vec, float m)
{
	t_vec3	new_vec;

	new_vec.x = vec.x * m;
	new_vec.y = vec.y * m;
	new_vec.z = vec.z * m;
	return (new_vec);
}

t_vec3	vec_invert(t_vec3 vec)
{
	return (v_init(-vec.x, -vec.y, -vec.z));
}

float	vec_distance(t_vec3 v1, t_vec3 v2)
{
	t_vec3	new_vec;

	new_vec.x = pow(v1.x - v2.x, 2);
	new_vec.y = pow(v1.y - v2.y, 2);
	new_vec.z = pow(v1.z - v2.z, 2);
	return (sqrt(new_vec.x + new_vec.y + new_vec.z));
}

float	vec_len(t_vec3 v1)
{
	return (sqrt(v1.x * v1.x + v1.y * v1.y + v1.z * v1.z));
}
