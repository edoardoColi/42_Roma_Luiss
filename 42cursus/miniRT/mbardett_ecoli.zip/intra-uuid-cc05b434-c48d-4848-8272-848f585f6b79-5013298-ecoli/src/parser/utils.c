/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/19 16:19:39 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/28 21:37:44 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parser.h"

// is char a space or a comma?
int	ft_spacom(char c)
{
	if (!c)
		return (0);
	if (ft_isspace(c) || c == ',')
		return (1);
	return (0);
}

// is char a valid one for our parser?
int	ft_isvalid(char c)
{
	if (!c || ft_spacom(c) || c == '\n')
		return (0);
	return (1);
}

// number of tokens to write into the cmtx
int	number_of_tokens(char *line)
{
	int	len;
	int	i;

	len = 0;
	i = 0;
	while (line[i] && line[i] != '\n')
	{
		while (ft_spacom(line[i]))
			i++;
		if (!line[i])
			break ;
		len = len + 1;
		while (ft_isvalid(line[i]))
			i++;
	}
	return (len);
}

int	no_chars(char **tkn)
{
	int	i;
	int	j;

	i = 1;
	j = 0;
	while (tkn[i])
	{
		j = 0;
		while (tkn[i][j])
		{
			if (ft_isalpha(tkn[i][j]))
			{
				printf("unexpected char: %c in row %d\n", tkn[i][j], i);
				return (1);
			}
			j++;
		}
		i++;
	}
	return (0);
}

int	cyl_values(t_cyl *c)
{
	if (c->versor.x > 1 || c->versor.x < -1 || c->versor.y > 1 
		|| c->versor.y < -1 || c->versor.z > 1 || c->versor.z < -1
		|| c->diam < EPS || c->heigth < EPS || c->rgb.x > 255
		|| c->rgb.z < 0 || c->rgb.y < 0 || c->rgb.y > 255
		|| c->rgb.z > 255 || c->rgb.z < 0)
		return (1);
	return (0);
}
