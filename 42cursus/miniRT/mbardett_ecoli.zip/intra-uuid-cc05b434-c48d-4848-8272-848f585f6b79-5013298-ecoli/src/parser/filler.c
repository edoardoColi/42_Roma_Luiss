/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   filler.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/19 16:39:09 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/28 21:34:53 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parser.h"

// NODE (?)
// printf("\nCAMERA:\npos [%f, %f, %f]\nver [%f, %f, %f]\nfov %f\n",
// 	c->pos.x, c->pos.y, c->pos.z,
// 	c->versor.x, c->versor.y, c->versor.z,
// 	c->fov);
static int	camera_set(t_scene *scene, char **token)
{
	t_cam	*c;
	t_cam	*last;

	if (ft_cmtx_len(token) != 8)
		return (err_set(scene, "wrong camera settings\n"));
	c = init_cam(scene);
	c->pos = v_init(set_float(token[CAM_X], 0),
			set_float(token[CAM_Y], 0), set_float(token[CAM_Z], 0));
	c->versor = v_init(set_float(token[CAM_V_X], 0),
			set_float(token[CAM_V_Y], 0), set_float(token[CAM_V_Z], 0));
	c->fov = set_float(token[CAM_FOV], 0);
	last = last_camera(scene->cams);
	if (!last)
		scene->cams = c;
	else
		last->next = c;
	if (c->versor.x > 1 || c->versor.x < -1 || c->versor.y > 1 
		|| c->versor.y < -1 || c->versor.z > 1 || c->versor.z < -1 
		|| c->fov >= 180 || c->fov <= 0)
		return (err_set(scene, "wrong camera ranges\n"));
	return (0);
}

// printf("\nLIGHT:\npos [%f, %f, %f]\nrgb [%f, %f, %f]\nfov %f\n",
// 	l->pos.x, l->pos.y, l->pos.z,
// 	l->rgb.x, l->rgb.y, l->rgb.z,
// 	l->bright);
static int	light_set(t_scene *scene, char **token)
{
	t_light	*l;
	t_light	*last;

	if (ft_cmtx_len(token) != 8)
		return (err_set(scene, "wrong light settings\n"));
	l = init_light(scene);
	l->pos = v_init(set_float(token[LIGHT_X], 0), set_float(token[LIGHT_Y], 0),
			set_float(token[LIGHT_Z], 0));
	l->bright = set_float(token[LIGHT_BRIGHT], 0);
	l->rgb = v_init(set_float(token[LIGHT_R], 0),
			set_float(token[LIGHT_G], 0), set_float(token[LIGHT_B], 0));
	last = last_light(scene->lights);
	if (!last)
		scene->lights = l;
	else
		last->next = l;
	if (l->bright > 1 || l->bright < 0 || l->rgb.x < 0 || l->rgb.x < 0
		|| l->rgb.y < 0 || l->rgb.y > 255 || l->rgb.z < 0 || l->rgb.z > 255)
		return (err_set(scene, "light values out of admitted ranges\n"));
	return (0);
}

static t_ambient	*last_ambient(t_ambient *ptr)
{
	if (ptr)
	{
		while (ptr->next)
			ptr = ptr->next;
	}
	return (ptr);
}

// printf("\nAMBIENT:\nrgb [%f, %f, %f]\nratio %f\n",
// 	a->rgb.x, a->rgb.y, a->rgb.z,
// 	a->ratio);
static int	ambient_set(t_scene *scene, char **token)
{
	t_ambient	*last;
	t_ambient	*a;

	if (ft_cmtx_len(token) != 5)
		return (err_set(scene, "wrong ambient light settings\n"));
	a = init_ambient_light(scene);
	a->ratio = set_float(token[AMB_RATIO], 0);
	a->rgb = v_init(set_float(token[AMB_X], 0),
			set_float(token[AMB_Y], 0), set_float(token[AMB_Z], 0));
	last = last_ambient(scene->amb);
	if (!last)
		scene->amb = a;
	else
		last->next = a;
	if (a->ratio > 1.0 || a->ratio < 0.0 || a->rgb.x < 0 || a->rgb.x > 255
		|| a->rgb.y < 0 || a->rgb.y > 255 || a->rgb.z < 0 || a->rgb.z > 255)
		return (err_set(scene, "amb values out of admitted ranges\n"));
	return (0);
}

// return 1 if an error is in the way
int	fill_scene(t_scene *scene, char **tkn)
{
	if (!strcmp(tkn[0], "A") && !no_chars(tkn))
		return (ambient_set(scene, tkn));
	else if (!strcmp(tkn[0], "C") && !no_chars(tkn))
		return (camera_set(scene, tkn));
	else if (!strcmp(tkn[0], "L") && !no_chars(tkn))
		return (light_set(scene, tkn));
	else if (!strcmp(tkn[0], "sp") && !no_chars(tkn))
		return (sphere_set(scene, tkn));
	else if (!strcmp(tkn[0], "pl") && !no_chars(tkn))
		return (plane_set(scene, tkn));
	else if (!strcmp(tkn[0], "cy") && !no_chars(tkn))
		return (cylinder_set(scene, tkn));
	else if (!strcmp(tkn[0], "pa") && !no_chars(tkn))
		return (paraboloid_set(scene, tkn));
	return (err_set(scene, "invalid .rt file\n"));
}
