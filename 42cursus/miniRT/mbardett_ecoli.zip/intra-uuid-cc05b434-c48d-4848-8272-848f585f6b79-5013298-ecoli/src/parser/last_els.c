/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   last_els.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/20 09:48:30 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/20 09:53:50 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parser.h"

t_plane	*last_plane(t_plane *ptr)
{
	if (ptr)
	{
		while (ptr->next)
			ptr = ptr->next;
	}
	return (ptr);
}

t_cyl	*last_cylinder(t_cyl *ptr)
{
	if (ptr)
	{
		while (ptr->next)
			ptr = ptr->next;
	}
	return (ptr);
}

t_sphere	*last_sphere(t_sphere *ptr)
{
	if (ptr)
	{
		while (ptr->next)
			ptr = ptr->next;
	}
	return (ptr);
}

t_cam	*last_camera(t_cam *ptr)
{
	if (ptr)
	{
		while (ptr->next)
			ptr = ptr->next;
	}
	return (ptr);
}

t_light	*last_light(t_light *ptr)
{
	if (ptr)
	{
		while (ptr->next)
			ptr = ptr->next;
	}
	return (ptr);
}
