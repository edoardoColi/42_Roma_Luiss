/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tokenize.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/19 15:00:21 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/20 10:07:35 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parser.h"

char	**tokenize(char *line, int line_end)
{
	int		i;
	int		j;
	int		k;
	char	**mtx;

	mtx = ft_calloc_cmtx(number_of_tokens(line));
	if (!(mtx))
		return (NULL);
	i = 0;
	j = 0;
	while (line && line[i] != '\n' && i != line_end)
	{
		while (line[i] && ft_spacom(line[i]))
			i++;
		if (!line[i])
			break ;
		mtx[j] = ft_calloc(sizeof(char), line_end + 1);
		k = 0;
		while (ft_isvalid(line[i]))
			mtx[j][k++] = line[i++];
		j++;
	}
	return (mtx);
}
