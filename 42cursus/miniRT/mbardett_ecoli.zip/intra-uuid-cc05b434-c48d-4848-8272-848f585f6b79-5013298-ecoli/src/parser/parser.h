/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parser.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/19 14:59:41 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/28 21:38:09 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PARSER_H
# define PARSER_H

# include "../../minirt.h"

# define AMB_RATIO 1
# define AMB_X 2
# define AMB_Y 3
# define AMB_Z 4

# define CAM_X 1
# define CAM_Y 2
# define CAM_Z 3
# define CAM_V_X 4
# define CAM_V_Y 5
# define CAM_V_Z 6
# define CAM_FOV 7

# define LIGHT_X 1
# define LIGHT_Y 2
# define LIGHT_Z 3
# define LIGHT_BRIGHT 4
# define LIGHT_R 5
# define LIGHT_G 6
# define LIGHT_B 7

# define SPHERE_X 1
# define SPHERE_Y 2
# define SPHERE_Z 3
# define SPHERE_DIAMETER 4
# define SPHERE_R 5
# define SPHERE_G 6
# define SPHERE_B 7

# define PLANE_OX 1
# define PLANE_OY 2
# define PLANE_OZ 3
# define PLANE_VX 4
# define PLANE_VY 5
# define PLANE_VZ 6
# define PLANE_R 7
# define PLANE_G 8
# define PLANE_B 9

# define CYL_PX 1
# define CYL_PY 2
# define CYL_PZ 3
# define CYL_VX 4
# define CYL_VY 5
# define CYL_VZ 6
# define CYL_DIAM 7
# define CYL_HEIGTH 8
# define CYL_R 9
# define CYL_G 10
# define CYL_B 11

char		**tokenize(char *c, int i);
int			number_of_tokens(char *l);
int			ft_isvalid(char c);
int			ft_spacom(char c);

int			cylinder_set(t_scene *s, char **c);
int			paraboloid_set(t_scene *s, char **c);
int			fill_scene(t_scene *s, char **c);
int			sphere_set(t_scene *s, char **c);
int			plane_set(t_scene *s, char **c);

t_sphere	*last_sphere(t_sphere *p);
t_cyl		*last_cylinder(t_cyl *p);
t_plane		*last_plane(t_plane *p);
t_light		*last_light(t_light *p);
t_cam		*last_camera(t_cam *p);
int			ft_buffend(char *str);
int			no_chars(char **tkn);
int			cyl_values(t_cyl *c);

#endif
