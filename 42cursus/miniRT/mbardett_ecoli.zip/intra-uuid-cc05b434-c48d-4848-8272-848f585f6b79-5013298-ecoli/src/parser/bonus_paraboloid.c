/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bonus_paraboloid.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/20 10:22:38 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/20 10:24:30 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parser.h"

// Bonus solid TODO
int	paraboloid_set(t_scene *scene, char **token)
{
	(void) scene;
	(void) token;
	return (0);
}
