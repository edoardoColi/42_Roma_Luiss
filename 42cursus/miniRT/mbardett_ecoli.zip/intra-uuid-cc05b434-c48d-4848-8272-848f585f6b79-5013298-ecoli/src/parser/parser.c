/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parser.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/19 15:00:18 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/28 21:35:53 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parser.h"

int	ft_buffend(char *str)
{
	int	len;

	len = strlen(str);
	while (ft_isspace(str[len]))
		len--;
	return (len);
}

int	line_empty(char *line)
{
	int	i;

	i = 0;
	while (line[i])
	{
		if (!ft_isspace(line[i]) && line[i] != '\n' && line[i] != ',')
			return (0);
		i++;
	}
	return (1);
}

int	arctia_parser(t_scene *scene, char *line, int fd)
{
	char	**mtx;
	int		error;

	line = gnl_so_long(fd);
	mtx = NULL;
	error = 0;
	while (line)
	{
		if (!line_empty(line) && !error)
		{
			mtx = tokenize(line, ft_buffend(line));
			error = fill_scene(scene, mtx);
			ft_free_cmtx(mtx);
		}
		ft_free_ptr(line);
		line = gnl_so_long(fd);
	}
	ft_free_ptr(line);
	if (error)
		exit_minirt(scene);
	return (0);
}

int	read_file(char *file_path, t_scene *scene)
{
	char	*line;
	int		fd;
	int		l;

	line = NULL;
	l = ft_strlen(file_path);
	if (l < 4)
		return (err_set(scene, "file should have the '.rt' extension\n"));
	if (!(file_path[l - 1] == 't' && file_path[l - 2] == 'r'
			&& file_path[l - 3] == '.'))
		return (err_set(scene, "file should have the '.rt' extension\n"));
	fd = open(file_path, O_RDONLY);
	if (fd == -1)
		return (err_set(scene, "cannot read the file in path specified\n"));
	return (arctia_parser(scene, line, fd));
}
