/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solids_filler.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/19 21:56:48 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/29 01:17:29 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parser.h"

// printf("\nSPHERE:\nori [%f, %f, %f]\nrgb [%f, %f, %f]\ndia %f\n",
// 	s->orig.x, s->orig.y, s->orig.z,
// 	s->rgb.x, s->rgb.y, s->rgb.z,
// 	s->diam);
int	sphere_set(t_scene *scene, char **token)
{
	t_sphere	*last;
	t_sphere	*s;

	if (ft_cmtx_len(token) != 8)
		return (err_set(scene, "wrong sphere settings\n"));
	s = init_sphere(scene);
	s->orig = v_init(set_float(token[SPHERE_X], 0),
			set_float(token[SPHERE_Y], 0), set_float(token[SPHERE_Z], 0));
	s->diam = set_float(token[SPHERE_DIAMETER], 0);
	s->rgb = v_init(set_float(token[SPHERE_R], 0),
			set_float(token[SPHERE_G], 0), set_float(token[SPHERE_B], 0));
	last = last_sphere(scene->spheres);
	if (!last)
		scene->spheres = s;
	else
		last->next = s;
	if (s->diam <= 0 || s->rgb.x > 255 || s->rgb.x < 0 || s->rgb.y > 255
		|| s->rgb.y < 0 || s->rgb.z < 0 || s->rgb.z > 255)
		return (err_set(scene, "sphere values out of admitted ranges\n"));
	return (0);
}

int	cylinder_set(t_scene *scene, char **token)
{
	t_cyl	*last;
	t_cyl	*c;

	if (ft_cmtx_len(token) != 12)
		return (err_set(scene, "wrong cylinder settings\n"));
	c = init_cylinder(scene);
	c->pos = v_init(set_float(token[CYL_PX], 0),
			set_float(token[CYL_PY], 0), set_float(token[CYL_PZ], 0));
	c->versor = v_init(set_float(token[CYL_VX], 0),
			set_float(token[CYL_VY], 0), set_float(token[CYL_VZ], 0));
	c->diam = set_float(token[CYL_DIAM], 0);
	c->heigth = set_float(token[CYL_HEIGTH], 0);
	c->rgb = v_init(set_float(token[CYL_R], 0),
			set_float(token[CYL_G], 0), set_float(token[CYL_B], 0));
	last = last_cylinder(scene->cyls);
	if (!last)
		scene->cyls = c;
	else
		last->next = c;
	if (cyl_values(c))
		return (err_set(scene, "cylinder values out of rangee\n"));
	c->versor.x += EPS * 10;
	c->versor.y += EPS * 10;
	return (0);
}

int	plane_set(t_scene *scene, char **token)
{
	t_plane	*last;
	t_plane	*p;

	if (ft_cmtx_len(token) != 10)
		return (err_set(scene, "wrong plane settings\n"));
	p = init_plane(scene);
	p->orig = v_init(set_float(token[PLANE_OX], 0),
			set_float(token[PLANE_OY], 0), set_float(token[PLANE_OZ], 0));
	p->versor = v_init(set_float(token[PLANE_VX], 0),
			set_float(token[PLANE_VY], 0), set_float(token[PLANE_VZ], 0));
	p->rgb = v_init(set_float(token[PLANE_R], 0),
			set_float(token[PLANE_G], 0), set_float(token[PLANE_B], 0));
	last = last_plane(scene->planes);
	if (!last)
		scene->planes = p;
	else
		last->next = p;
	if (p->versor.x > 1 || p->versor.x < -1 || p->versor.y > 1
		|| p->versor.y < -1 || p->versor.z < -1 || p->versor.z > 1
		|| p->rgb.x > 255 || p->rgb.x < 0 || p->rgb.y > 255 || p->rgb.y < 0
		|| p->rgb.z > 255 || p->rgb.z < 0)
		return (err_set(scene, "plane values out of range\n"));
	return (0);
}
