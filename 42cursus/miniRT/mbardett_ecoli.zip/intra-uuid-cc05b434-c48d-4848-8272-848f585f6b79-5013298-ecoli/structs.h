/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   structs.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/28 17:24:40 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/28 21:13:23 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef STRUCTS_H
# define STRUCTS_H

typedef unsigned int	t_color;

typedef struct s_pnt2
{
	int	x;
	int	y;
}	t_pnt2;

typedef struct s_pnt3
{
	float	x;
	float	y;
	float	z;
}	t_pnt3;

//conviene aggiungere origine del raggio/vettore?
typedef struct s_vec3
{
	float	x;
	float	y;
	float	z;
}	t_vec3;

typedef struct t_ray
{
	t_vec3	origin;
	t_vec3	dir;
}	t_ray;

typedef struct s_light
{
	char					*type;
	float					x;
	float					y;
	float					z;
	float					bright;
	t_vec3					pos;
	t_vec3					rgb;
	struct s_light			*next;
}	t_light;

typedef struct s_cam
{
	char					*type;
	t_vec3					x;
	t_vec3					y;
	t_vec3					z;
	t_vec3					pos;
	t_vec3					versor;
	float					fov;
	struct s_cam			*next;
}	t_cam;

typedef struct s_ambient
{
	float					ratio;
	t_vec3					rgb;
	int						amb_n;
	struct s_ambient		*next;
}	t_ambient;

typedef struct s_sphere
{
	char					type;
	t_vec3					orig;
	float					diam;
	t_vec3					rgb;
	struct s_sphere			*next;
}	t_sphere;

typedef struct s_cyl
{
	char					*type;
	float					x;
	float					y;
	float					z;
	t_vec3					pos;
	t_vec3					versor;
	float					diam;
	float					heigth;
	t_vec3					rgb;
	struct s_cyl			*next;
}	t_cyl;

typedef struct s_plane
{
	char					type;
	t_vec3					orig;
	t_vec3					versor;
	t_vec3					rgb;
	struct s_plane			*next;
}	t_plane;

typedef struct s_obj
{
	t_cam					*cam;
	t_sphere				*spheres;
	t_cyl					*cyl;
	t_plane					*plane;
}	t_obj;

typedef struct s_end_light
{
	t_color	color;
	float	bright;
}	t_end_light;

typedef struct s_img
{
	void	*img;
	char	*data;

	int		pxlb;
	int		lineb;
	int		endian;
}	t_img;

typedef struct s_scene
{
	void					*mlx;
	void					*mlx_win;
	t_img					*mlx_img;

	float					width;
	float					heigth;
	int						n_lights;
	int						n_cams;
	int						n_spheres;
	int						n_cyls;
	int						n_planes;

	t_cam					*cams_selez;
	t_cam					*cams;
	t_sphere				*spheres;
	t_cyl					*cyls;
	t_plane					*planes;
	t_obj					*objs;
	t_light					*lights;
	t_ambient				*amb;

	t_end_light				end_light;
	struct s_selected		*sel;
	struct s_collision		*col;

	char					*error_msg;
}	t_scene;

typedef struct s_collision
{
	int			type;
	float		dist;

	float		sol1;
	float		sol2;
	float		sol_min;
	t_vec3		base_norm;

	t_cyl		*cyl;
	t_plane		*pla;
	t_sphere	*sph;
}	t_collision;

typedef struct s_selected
{
	int		type;
	void	*obj;
}	t_selected;

typedef struct s_calc
{
	float	a;
	float	b;
	float	c;
	float	disc;
}	t_calc;

#endif
