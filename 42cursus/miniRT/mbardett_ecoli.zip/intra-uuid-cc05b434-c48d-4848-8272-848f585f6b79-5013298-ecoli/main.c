/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/28 23:54:14 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/29 01:33:58 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minirt.h"

void	set_first_selection(t_scene *scene)
{
	scene->sel->type = camera;
	scene->sel->obj = scene->cams;
}

void	check_obligations(t_scene *scene)
{
	if (scene->cams == NULL || scene->lights == NULL || scene->amb == NULL)
	{
		err_set(scene, "missing one important parameter\n");
		exit_minirt(scene);
	}
}

int	main(int argc, char **argv)
{
	t_scene	scene;

	init_scene(&scene);
	if (argc != 2 && err_set(&scene, "wrong number of arguments\n"))
		exit_minirt(&scene);
	if (read_file(argv[1], &scene))
		exit_minirt(&scene);
	check_obligations(&scene);
	scene.cams_selez = scene.cams;
	mlx_hook(scene.mlx_win, 17, 0, window_cross, &scene);
	mlx_key_hook(scene.mlx_win, keyboard_manage, &scene);
	set_first_selection(&scene);
	render_loop(&scene);
	mlx_loop(scene.mlx);
	exit_minirt(&scene);
	return (0);
}
