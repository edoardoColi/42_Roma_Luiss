/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_free.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/18 20:52:49 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/28 21:13:00 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_free_ptr(void *ptr)
{
	if (ptr)
		free(ptr);
}

void	ft_free_mtx(void **mtx)
{
	size_t	i;

	i = 0;
	if (mtx)
	{
		while (mtx[i])
			ft_free_ptr(mtx[i++]);
		free(mtx);
	}
}

void	ft_free_cmtx(char	**mtx)
{
	size_t	i;

	i = 0;
	if (mtx)
	{
		while (mtx[i])
			ft_free_ptr(mtx[i++]);
		free(mtx);
	}
}
