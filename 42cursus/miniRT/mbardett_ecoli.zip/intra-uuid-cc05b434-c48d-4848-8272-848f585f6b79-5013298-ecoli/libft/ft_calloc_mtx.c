/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc_mtx.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/20 10:04:20 by vgavioli          #+#    #+#             */
/*   Updated: 2023/07/20 10:07:28 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	**ft_calloc_cmtx(size_t len)
{
	char	**cmtx;
	size_t	i;

	cmtx = (char **) malloc(sizeof(char *) * (len + 1));
	if (!cmtx)
		return (NULL);
	i = 0;
	while (i < len + 1)
		cmtx[i++] = NULL;
	return (cmtx);
}
