/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgavioli <vgavioli@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/02 04:14:26 by eddy              #+#    #+#             */
/*   Updated: 2023/07/28 21:09:28 by vgavioli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minirt.h"

float	ft_atofrt(const char *str)
{
	int			i;
	int			s;
	int			pow;
	float		ret;

	pow = 0;
	s = 1;
	i = 0;
	ret = 0;
	while (str[i] == '\t' || str[i] == '\n' || str[i] == '\v'
		|| str[i] == '\f' || str[i] == '\r' || str[i] == ' ')
		i++;
	if (str[i] == '-' || str[i] == '+')
	{
		if (str[i] == '-')
			s = -1;
		i++;
	}
	i--;
	while (ft_isdigit(str[++i]))
		ret = ret * 10 + (str[i] - 48);
	if (str[i] == '.' && ft_isdigit(str[i + 1]))
		while (ft_isdigit(str[++i]))
			ret = ret + ((str[i] -48) / powf(10, ++pow));
	return (s * ret);
}

int	ft_isspace(char c)
{
	if (c == ' ' || c == '\t' || c == '\n' || c == '\v'
		|| c == '\f' || c == '\r')
		return (1);
	return (0);
}

t_color	rgb_to_int(int r, int g, int b)
{
	t_color	color;

	color = (r << 16) | (g << 8) | b;
	return (color);
}

t_color	vec_rgb_to_int(t_vec3 c)
{
	return (rgb_to_int(c.x, c.y, c.z));
}
